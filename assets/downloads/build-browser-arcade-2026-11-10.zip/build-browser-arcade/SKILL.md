---
name: build-browser-arcade
description: Build or extend a small pixel-art browser arcade embedded in an existing website. Use for a playable loop with reference-based characters, readable dialogue, audio, an attract demo, and a separate reusable game source repository.
---

# Build a browser arcade

Make one approved playable loop and a clean website embed. Get the reference, scale and joke right before multiplying assets or adding rooms.

## Start with the result

Inspect the existing source, host integration and latest approved preview. Reuse them instead of starting another engine. Establish which repository holds the game, which holds the public site, and what the user means by push: branch backup, review PR, or live publication. These are separate outcomes.

Capture a short acceptance list from the request: who the player is, the first interaction, what happens after victory, reference fidelity, viewport size, controls, sound and motion. If choices are already approved, carry them forward. Do not restart a design interview.

For the Classic Cottrell implementation, read [the project reference](references/classic-cottrell.md) only when working on that game or borrowing its implementation.

## Approve a frame before a sheet

- Use the actual supplied reference. Inspect it before editing. A supplied face or logo should remain that face or logo; resizing, rasterization and palette conversion are different jobs from inventing a replacement.
- Show one hero, one pickup and one background together at the intended on-screen scale, at desktop and phone widths. Judge pickups against the hero, not a large contact sheet. Keep the selected variant identifiable.
- Agree on the internal resolution, palette, source density and atlas anchor before producing animation frames. Distinguish sheet pixels, world units and CSS display pixels. Check silhouettes, feet and hitboxes in motion.
- Store lossless sources and generation prompts in the game repo. Keep alpha binary and disable smoothing for hard pixels. Run the existing palette checker after PNG changes. Do not regenerate approved assets to make a small size or placement change.

## Build the joke into the first encounter

Finish movement, one opponent, dialogue, hit feedback and a restart before adding waves. Make the intended joke visible when enemies arrive, rather than several encounters later. Keep each bubble attached to its speaker, clamp it to the viewport, preserve the complete text and give longer lines more reading time. Keep dialogue duration separate from attack timing.

Once the loop works, add the agreed wave sequence and boss, then verify the next lap resets enemies and pickups. Park unfinished rooms explicitly. An attract demo should drive the real combat system, cancel on real input, fade and reset; avoid a second simulation that can drift from gameplay.

## Treat sound as part of the playable result

Check that the real music file exists in the active checkout and returns successfully from the dev server. A stubbed audio test does not verify the supplied track. Keep authored sound previews separate from the game mix.

Request audio from an intentional reveal/start action and obey browser activation limits. If blocked, leave a clear Start sound control. Share mute across music and effects, and stop voices on hide, replay and destroy. Do not imply that scrolling guarantees audio playback.

## Keep source and website apart

The game repo owns editable art, engine, tests, prompts and handoff notes. Export an allowlisted, versioned runtime to the host; never copy the whole checkout. Confirm permission before including a supplied track in a public export. Keep source-only music out of commits when required by the project.

Mount lazily into the existing website layout. Keep normal content usable without JavaScript and when loading fails. Put sound, help, fullscreen and close inside the game window. Close must destroy the game and restore focus to its launcher. Make help compact. Honour reduced motion in both game and host animation.

## Keep iteration cheap

Change the smallest layer responsible: world draw size for a smaller pickup, speech lifetime for reading time, host CSS for the reveal strip. Run affected tests and inspect the actual result. Reuse a reachable dev server and existing browser coverage. Run the release gate when publishing, rather than after every cosmetic preview. Delegate only independent bounded work or roles required by the repository.

Before releasing a new or extended loop, verify the normal and reduced-motion desktop/phone flows, real music, first encounter, boss/reset, close/focus, and exported asset requests. For a narrow preview change, check only affected behaviour until publication is requested. State which checks were automated or emulated and which physical devices remain unchecked. A pushed branch is not a deployed site: inspect the deployed runtime version and exercise Play, dialogue and Close on the public URL after an authorized release.

Leave a current entry point, reproducible commands, asset provenance, known gaps and the next smallest extension in the standalone game repo. Do not replace working history with a fresh repository just to tidy it.
