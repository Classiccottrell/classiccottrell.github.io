# Classic Cottrell reference implementation

This is a project profile, not mandatory numbers for every arcade.

- Private source: `https://github.com/Classiccottrell/cc-sidescroller`.
- Public host: `https://github.com/Classiccottrell/classiccottrell.github.io`, production `https://classiccottrell.ca/` on Netlify. The host's default branch is `master`; the game's is `main`.
- Read `README.md`, `BRIEF.md`, `docs/release-2026-11-10.md`, then the binding art section in `docs/design.md`. Earlier handoff entries record superseded choices.
- Canvas 2D + native ES modules, fixed 60 Hz combat, no runtime dependencies. `src/engine/game.js` exposes `mountGame` and lifecycle controls.
- Internal height 180, browser-width view, integer CSS scale. Character cells 128×128 at density 2; render scale is separate from source density. The palette has at most 32 colours in `art/palette.json`.
- Current loop: office-feedback opening, two-person/two-monster second wave, two more office rounds, Overlay/Auditor, solo Warlord Z-Index; six waves total. Victory then walking right starts a fresh lap. Vault door is hidden; room source remains.
- `src/combat/data.js`: waves, enemy lines and combat numbers. `src/combat/enemy.js`: entrance/attack/defeat speech and its 5–7 second lifetime. `src/combat/draw.js` and `src/engine/dialogue.js`: speaker selection and DOM bubble. Reading time is not attack windup.
- Approved Terry option C: `art/pickups/terry-emblem.png`, drawn 24×24 world units by `src/combat/terry.js`. Use the source face, not another generated interpretation. Developer mark: `src/boot/developer-2c.png`, adapted from Matt's original 2C favicon with alpha preserved.
- `src/audio/preview.html` and `tools/sound-workbench.html` are existing sound-design tools. Synth SFX/title music are in `src/audio/`; optional level music is handled by `src/music.js`.
- `src/attract/demo.js`: real-combat scripted input and cancellation. `src/title/sequence.js`: intro and developer card. `src/engine/touch.js`: native controls and warm game chrome.
- Local dev: `npm run serve` on 8080. Unit suite: `npm test`. Browser suite: install dev dependencies with `npm ci`, use installed Chrome, then `npm run test:browser` against the running server. `BASE_URL` overrides the browser URL.
- PNG validation: `python tools/check-pngs.py` with Pillow installed in a development environment. Existing art cleanup/generation tools are beside their assets; don't add those dependencies to the runtime.
- The ignored track `local-audio/level-3-shadow-fortress.mp3` must be restored locally for the real-audio browser suite and `npm run build`. The game can run without the optional song, but a silent run does not validate it. Matt authorized the track's public runtime use; the private source MP3 remains uncommitted.
- `tools/build-runtime.mjs` follows module imports and selected assets into ignored `dist/`, including a content-addressed manifest. The website's `scripts/vendor-arcade.mjs` imports that directory and updates `data/arcade.json`.
- Host: `scripts/lib/layout.mjs`, `assets/js/cartridge.js`, `assets/css/site.css`; coverage: `tests/cartridge.spec.js`. Play or upward scrolling at the top reveals; audio is requested but may require Start sound. The bottom-border glint is static under reduced motion.
- Preserve the existing historical `v0.1.0` tag. The source at `61c7674` produced live runtime `v0.1.0-36a7927e58`, released through website PR #36, merge `4d487c1`. Later documentation commits do not change that runtime unless imported code/assets change.
- Common traps: guessing reference art; approving pickups only at enlarged scale; missing ignored music in a clone; confusing source pixels with draw size; regenerating approved artwork for CSS changes; running whole release pipelines on each preview; saying live after only a branch push.
